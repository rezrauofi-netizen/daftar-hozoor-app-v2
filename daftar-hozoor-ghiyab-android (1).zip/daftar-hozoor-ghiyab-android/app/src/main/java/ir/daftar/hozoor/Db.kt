package ir.daftar.hozoor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

data class Student(val id: Long, val name: String)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "attendance.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, pos INTEGER NOT NULL)")
        db.execSQL(
            "CREATE TABLE att(student_id INTEGER NOT NULL, month INTEGER NOT NULL, day INTEGER NOT NULL, " +
                "status INTEGER NOT NULL, PRIMARY KEY(student_id, month, day), " +
                "FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // نسخه ۱: بدون مهاجرت؛ در نسخه‌های بعدی داده‌ها نباید پاک شوند.
    }

    fun getMeta(k: String): String {
        val c = readableDatabase.rawQuery("SELECT v FROM meta WHERE k=?", arrayOf(k))
        try {
            return if (c.moveToFirst()) c.getString(0) else ""
        } finally {
            c.close()
        }
    }

    fun setMeta(k: String, v: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", arrayOf<Any>(k, v))
    }

    fun students(q: String): List<Student> {
        val list = ArrayList<Student>()
        val blank = q.isBlank()
        val sql = if (blank) "SELECT id,name FROM students ORDER BY pos,id"
        else "SELECT id,name FROM students WHERE name LIKE ? ORDER BY pos,id"
        val args: Array<String>? = if (blank) null else arrayOf("%" + q.trim() + "%")
        val c = readableDatabase.rawQuery(sql, args)
        try {
            while (c.moveToNext()) list.add(Student(c.getLong(0), c.getString(1)))
        } finally {
            c.close()
        }
        return list
    }

    fun addStudent(name: String) {
        val w = writableDatabase
        var pos = 1
        val c = w.rawQuery("SELECT COALESCE(MAX(pos),0)+1 FROM students", null)
        try {
            if (c.moveToFirst()) pos = c.getInt(0)
        } finally {
            c.close()
        }
        val cv = ContentValues()
        cv.put("name", name)
        cv.put("pos", pos)
        w.insertOrThrow("students", null, cv)
    }

    fun renameStudent(id: Long, name: String) {
        val cv = ContentValues()
        cv.put("name", name)
        writableDatabase.update("students", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteStudent(id: Long) {
        writableDatabase.delete("students", "id=?", arrayOf(id.toString()))
    }

    /** studentId -> وضعیت هر روز (اندیس ۱..۳۱) */
    fun monthMap(month: Int): HashMap<Long, IntArray> {
        val map = HashMap<Long, IntArray>()
        val c = readableDatabase.rawQuery(
            "SELECT student_id, day, status FROM att WHERE month=?", arrayOf(month.toString())
        )
        try {
            while (c.moveToNext()) {
                val arr = map.getOrPut(c.getLong(0)) { IntArray(32) }
                val d = c.getInt(1)
                if (d in 1..31) arr[d] = c.getInt(2)
            }
        } finally {
            c.close()
        }
        return map
    }

    fun setStatus(sid: Long, month: Int, day: Int, status: Int) {
        val w = writableDatabase
        if (status == 0) {
            w.delete("att", "student_id=? AND month=? AND day=?", arrayOf(sid.toString(), month.toString(), day.toString()))
        } else {
            val cv = ContentValues()
            cv.put("student_id", sid)
            cv.put("month", month)
            cv.put("day", day)
            cv.put("status", status)
            w.insertWithOnConflict("att", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    /** studentId -> [ماه][حضور، غیبت، تأخیر] */
    fun counts(): HashMap<Long, Array<IntArray>> {
        val map = HashMap<Long, Array<IntArray>>()
        val c = readableDatabase.rawQuery(
            "SELECT student_id, month, status, COUNT(*) FROM att WHERE status>0 GROUP BY student_id, month, status", null
        )
        try {
            while (c.moveToNext()) {
                val arr = map.getOrPut(c.getLong(0)) { Array(9) { IntArray(3) } }
                val m = c.getInt(1)
                val s = c.getInt(2)
                if (m in 0..8 && s in 1..3) arr[m][s - 1] = c.getInt(3)
            }
        } finally {
            c.close()
        }
        return map
    }
}

class Parsed(
    val meta: Map<String, String>,
    val students: List<Triple<Long, String, Int>>,
    val records: List<LongArray>
)

object Backup {
    private const val FORMAT = "daftar-hozoor-ghiyab"
    val META_KEYS = listOf("school", "cls", "teacher", "year")

    fun export(db: Db): JSONObject {
        val o = JSONObject()
        o.put("format", FORMAT)
        o.put("version", 1)
        val meta = JSONObject()
        for (k in META_KEYS) meta.put(k, db.getMeta(k))
        o.put("meta", meta)

        val sa = JSONArray()
        val r = db.readableDatabase
        var c = r.rawQuery("SELECT id,name,pos FROM students ORDER BY pos,id", null)
        try {
            while (c.moveToNext()) {
                val s = JSONObject()
                s.put("id", c.getLong(0))
                s.put("name", c.getString(1))
                s.put("pos", c.getInt(2))
                sa.put(s)
            }
        } finally {
            c.close()
        }
        o.put("students", sa)

        val ra = JSONArray()
        c = r.rawQuery("SELECT student_id,month,day,status FROM att WHERE status>0", null)
        try {
            while (c.moveToNext()) {
                val x = JSONObject()
                x.put("s", c.getLong(0))
                x.put("m", c.getInt(1))
                x.put("d", c.getInt(2))
                x.put("t", c.getInt(3))
                ra.put(x)
            }
        } finally {
            c.close()
        }
        o.put("records", ra)
        return o
    }

    private fun bad(msg: String): Nothing = throw IllegalArgumentException(msg)

    fun parse(text: String): Parsed {
        val o = try {
            JSONObject(text)
        } catch (e: Exception) {
            bad("این فایل، فایل پشتیبان معتبر نیست (ساختار JSON نادرست).")
        }
        if (o.optString("format") != FORMAT) bad("این فایل متعلق به این برنامه نیست.")
        if (o.optInt("version", 0) != 1) bad("نسخه فایل پشتیبان پشتیبانی نمی‌شود.")
        val m = o.optJSONObject("meta") ?: bad("بخش مشخصات مدرسه در فایل وجود ندارد.")
        val meta = HashMap<String, String>()
        for (k in META_KEYS) meta[k] = m.optString(k, "")

        val sa = o.optJSONArray("students") ?: bad("فهرست دانش‌آموزان در فایل وجود ندارد.")
        val ids = HashSet<Long>()
        val students = ArrayList<Triple<Long, String, Int>>()
        for (i in 0 until sa.length()) {
            val s = sa.optJSONObject(i) ?: bad("ردیف دانش‌آموز شماره ${i + 1} نامعتبر است.")
            val id = s.optLong("id", -1)
            val name = s.optString("name", "").trim()
            if (id <= 0 || name.isEmpty() || !ids.add(id)) bad("اطلاعات دانش‌آموز شماره ${i + 1} نامعتبر است.")
            students.add(Triple(id, name, s.optInt("pos", i + 1)))
        }

        val ra = o.optJSONArray("records") ?: bad("سوابق حضور و غیاب در فایل وجود ندارد.")
        val recs = ArrayList<LongArray>()
        for (i in 0 until ra.length()) {
            val x = ra.optJSONObject(i) ?: bad("ثبت شماره ${i + 1} نامعتبر است.")
            val sid = x.optLong("s", -1)
            val mo = x.optInt("m", -1)
            val d = x.optInt("d", 0)
            val t = x.optInt("t", -1)
            if (!ids.contains(sid) || mo !in 0..8 || d < 1 || d > Fa.daysIn[mo] || t !in 1..3) {
                bad("ثبت حضور و غیاب شماره ${i + 1} نامعتبر است.")
            }
            recs.add(longArrayOf(sid, mo.toLong(), d.toLong(), t.toLong()))
        }
        return Parsed(meta, students, recs)
    }

    fun restore(db: Db, p: Parsed) {
        val w = db.writableDatabase
        w.beginTransaction()
        try {
            w.delete("att", null, null)
            w.delete("students", null, null)
            w.delete("meta", null, null)
            for ((k, v) in p.meta) w.execSQL("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", arrayOf<Any>(k, v))
            for (s in p.students) {
                val cv = ContentValues()
                cv.put("id", s.first)
                cv.put("name", s.second)
                cv.put("pos", s.third)
                w.insertOrThrow("students", null, cv)
            }
            for (r in p.records) {
                val cv = ContentValues()
                cv.put("student_id", r[0])
                cv.put("month", r[1].toInt())
                cv.put("day", r[2].toInt())
                cv.put("status", r[3].toInt())
                w.insertWithOnConflict("att", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }
}
