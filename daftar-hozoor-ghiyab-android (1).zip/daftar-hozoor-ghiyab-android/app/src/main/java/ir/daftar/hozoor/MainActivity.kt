package ir.daftar.hozoor

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var db: Db
    private lateinit var content: LinearLayout
    private var month = 0

    private val createLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) writeBackup(uri)
        }
    private val openLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBackup(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        month = getSharedPreferences("ui", MODE_PRIVATE).getInt("month", 0).coerceIn(0, 8)

        val root = vbox()
        root.setBackgroundColor(C.BG)
        val scroll = ScrollView(this)
        content = vbox()
        content.setPadding(dp(8), dp(8), dp(8), dp(8))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(buildBottomBar())
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        content.removeAllViews()
        content.addView(buildTitle())
        content.addView(buildFields())
        content.addView(buildMonths())
        content.addView(buildTable(), lp(MATCH, WRAP, 0f, 3))
        content.addView(buildLegend())
    }

    private fun buildTitle(): View {
        val row = hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        val t = tv("حضور و غیاب ماه " + Fa.months[month], 22f, C.NAVY, true)
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = dpf(28)
        bg.setStroke(dp(2), C.YELLOW_D, dpf(6), dpf(4))
        t.background = bg
        t.setPadding(dp(12), dp(16), dp(12), dp(16))
        row.addView(tv("☀️", 30f))
        row.addView(t, lp(0, WRAP, 1f, 4))
        row.addView(tv("✏️", 30f))
        return row
    }

    private fun fieldCard(label: String, key: String, bg: Int, border: Int): View {
        val box = vbox()
        box.background = shape(bg, border, dpf(14), dp(2))
        box.setPadding(dp(10), dp(6), dp(10), dp(8))
        val l = tv(label, 13f, C.NAVY, true)
        l.gravity = Gravity.START
        val value = db.getMeta(key)
        val v = tv(if (value.isBlank()) "………………" else value, 15f)
        v.gravity = Gravity.START
        box.addView(l)
        box.addView(v)
        box.setOnClickListener { editMeta(label, key) }
        return box
    }

    private fun buildFields(): View {
        val grid = vbox()
        val r1 = hbox()
        r1.addView(fieldCard("نام مدرسه:", "school", C.PINK, C.PINK_D), lp(0, WRAP, 1f))
        r1.addView(fieldCard("نام کلاس:", "cls", C.GREEN, C.GREEN_D), lp(0, WRAP, 1f))
        val r2 = hbox()
        r2.addView(fieldCard("نام مربی:", "teacher", C.YELLOW, C.YELLOW_D), lp(0, WRAP, 1f))
        r2.addView(fieldCard("سال تحصیلی:", "year", C.SKY, C.LINE), lp(0, WRAP, 1f))
        grid.addView(r1)
        grid.addView(r2)
        return grid
    }

    private fun editMeta(label: String, key: String) {
        val et = EditText(this)
        et.setText(db.getMeta(key))
        et.setSingleLine()
        et.textDirection = View.TEXT_DIRECTION_RTL
        AlertDialog.Builder(this)
            .setTitle(label)
            .setView(et)
            .setPositiveButton("ذخیره") { _, _ ->
                db.setMeta(key, et.text.toString().trim())
                render()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun buildMonths(): View {
        val hs = HorizontalScrollView(this)
        hs.layoutDirection = View.LAYOUT_DIRECTION_RTL
        hs.isHorizontalScrollBarEnabled = false
        val row = hbox()
        for (i in 0..8) {
            val sel = i == month
            val t = tv(Fa.months[i], 14f, if (sel) Color.WHITE else C.NAVY, true)
            t.background = shape(if (sel) C.BLUE else Color.WHITE, C.BLUE, dpf(16), dp(1))
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setOnClickListener {
                month = i
                getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("month", i).apply()
                render()
            }
            row.addView(t, lp(WRAP, WRAP, 0f, 4))
        }
        hs.addView(row)
        return hs
    }

    private fun styleCell(c: TextView, st: Int) {
        var fill = Color.WHITE
        var txt = ""
        var col = C.TEXT
        when (st) {
            1 -> { fill = C.PRES_BG; txt = "ح"; col = C.PRES_T }
            2 -> { fill = C.ABS_BG; txt = "غ"; col = C.ABS_T }
            3 -> { fill = C.LATE_BG; txt = "ت"; col = C.LATE_T }
        }
        c.text = txt
        c.setTextColor(col)
        c.background = shape(fill, C.LINE, 0f, dp(1))
    }

    private fun updateStats(v: Array<TextView>, arr: IntArray, nDays: Int) {
        var p = 0
        var a = 0
        var l = 0
        for (d in 1..nDays) {
            when (arr[d]) {
                1 -> p++
                2 -> a++
                3 -> l++
            }
        }
        v[0].text = Fa.n(l)
        v[1].text = Fa.n(a)
        v[2].text = Fa.n(p)
    }

    private fun buildTable(): View {
        val students = db.students("")
        if (students.isEmpty()) {
            val t = tv("هنوز دانش‌آموزی ثبت نشده است.\nاز دکمه «دانش‌آموزان» در پایین صفحه اضافه کنید.", 15f, C.NAVY)
            t.setPadding(dp(12), dp(40), dp(12), dp(40))
            return t
        }
        val data = db.monthMap(month)
        val nDays = Fa.daysIn[month]
        val rowH = dp(44)
        val hdrH = dp(30)
        val cellW = dp(38)
        val nameW = dp(130)
        val idxW = dp(38)
        val statW = dp(46)
        val statViews = HashMap<Long, Array<TextView>>()

        // ستون ردیف و نام (سمت راست)
        val nameBlock = vbox()
        val nh = hbox()
        nh.addView(cell("ردیف", idxW, hdrH * 2, C.HEAD_BG, C.NAVY, 12f, true))
        nh.addView(cell("نام و نام خانوادگی", nameW, hdrH * 2, C.HEAD_BG, C.NAVY, 12f, true))
        nameBlock.addView(nh)
        students.forEachIndexed { i, s ->
            val r = hbox()
            r.addView(cell(Fa.n(i + 1), idxW, rowH, C.HEAD_BG, C.NAVY, 13f, true))
            val nm = cell(s.name, nameW, rowH, Color.WHITE)
            nm.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            r.addView(nm)
            nameBlock.addView(r)
        }

        // روزها (وسط، قابل پیمایش افقی؛ روز ۱ سمت راست)
        val daysCol = vbox()
        daysCol.addView(cell("روزهای " + Fa.months[month], cellW * nDays, hdrH, C.HEAD_BG, C.NAVY, 14f, true))
        val dayHdr = hbox()
        for (d in 1..nDays) dayHdr.addView(cell(Fa.n(d), cellW, hdrH, C.HEAD_BG, C.NAVY, 12f, true))
        daysCol.addView(dayHdr)

        // ستون آمار (سمت چپ)
        val statBlock = vbox()
        val sh = hbox()
        sh.addView(cell("تعداد\nتأخیر", statW, hdrH * 2, C.LATE_BG, C.NAVY, 11f, true))
        sh.addView(cell("تعداد\nغیبت", statW, hdrH * 2, C.PINK, C.NAVY, 11f, true))
        sh.addView(cell("تعداد\nحضور", statW, hdrH * 2, C.YELLOW, C.NAVY, 11f, true))
        statBlock.addView(sh)

        for (s in students) {
            val arr = data.getOrPut(s.id) { IntArray(32) }
            val sv = arrayOf(
                cell("", statW, rowH, C.LATE_BG, C.NAVY, 14f, true),
                cell("", statW, rowH, C.PINK, C.NAVY, 14f, true),
                cell("", statW, rowH, C.YELLOW, C.NAVY, 14f, true)
            )
            statViews[s.id] = sv
            updateStats(sv, arr, nDays)
            val sr = hbox()
            for (x in sv) sr.addView(x)
            statBlock.addView(sr)

            val row = hbox()
            for (d in 1..nDays) {
                val c = cell("", cellW, rowH, Color.WHITE, C.TEXT, 15f, true)
                styleCell(c, arr[d])
                c.setOnClickListener {
                    arr[d] = (arr[d] + 1) % 4
                    db.setStatus(s.id, month, d, arr[d])
                    styleCell(c, arr[d])
                    updateStats(sv, arr, nDays)
                }
                row.addView(c)
            }
            daysCol.addView(row)
        }

        val hs = HorizontalScrollView(this)
        hs.layoutDirection = View.LAYOUT_DIRECTION_RTL
        hs.addView(daysCol)

        val whole = hbox()
        whole.addView(nameBlock, LinearLayout.LayoutParams(WRAP, WRAP))
        whole.addView(hs, LinearLayout.LayoutParams(0, WRAP, 1f))
        whole.addView(statBlock, LinearLayout.LayoutParams(WRAP, WRAP))
        return whole
    }

    private fun buildLegend(): View {
        val row = hbox()
        row.gravity = Gravity.CENTER
        row.setPadding(0, dp(8), 0, dp(8))
        val a = tv("ح = حاضر", 12f, C.PRES_T, true)
        a.background = shape(C.PRES_BG, C.PRES_BG, dpf(10), dp(1))
        val b = tv("غ = غایب", 12f, C.ABS_T, true)
        b.background = shape(C.ABS_BG, C.ABS_BG, dpf(10), dp(1))
        val c = tv("ت = تأخیر", 12f, C.LATE_T, true)
        c.background = shape(C.LATE_BG, C.LATE_BG, dpf(10), dp(1))
        for (x in listOf(a, b, c)) {
            x.setPadding(dp(10), dp(4), dp(10), dp(4))
            row.addView(x, lp(WRAP, WRAP, 0f, 4))
        }
        val box = vbox()
        box.addView(row)
        box.addView(tv("با لمس هر خانه: خالی ← حاضر ← غایب ← تأخیر ← خالی", 12f, C.NAVY))
        return box
    }

    private fun buildBottomBar(): View {
        val bar = hbox()
        bar.setBackgroundColor(Color.WHITE)
        bar.setPadding(dp(4), dp(4), dp(4), dp(4))
        val b1 = button("دانش‌آموزان")
        b1.setOnClickListener { startActivity(Intent(this, StudentsActivity::class.java)) }
        val b2 = button("گزارش", C.GREEN_D)
        b2.setOnClickListener { startActivity(Intent(this, ReportActivity::class.java)) }
        val b3 = button("پشتیبان‌گیری", C.NAVY)
        b3.setOnClickListener { createLauncher.launch("daftar-hozoor-backup.json") }
        val b4 = button("بازیابی", C.PINK_D)
        b4.setOnClickListener { openLauncher.launch(arrayOf("*/*")) }
        for (b in listOf(b1, b2, b3, b4)) bar.addView(b, lp(0, WRAP, 1f, 3))
        return bar
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun writeBackup(uri: Uri) {
        try {
            val bytes = Backup.export(db).toString(2).toByteArray(Charsets.UTF_8)
            val os = contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("خروجی در دسترس نیست")
            os.use { it.write(bytes) }
            toast("نسخه پشتیبان ذخیره شد.")
        } catch (e: Exception) {
            toast("ذخیره پشتیبان ناموفق بود.")
        }
    }

    private fun readBackup(uri: Uri) {
        val text = try {
            val ins = contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل در دسترس نیست")
            ins.use { String(it.readBytes(), Charsets.UTF_8) }
        } catch (e: Exception) {
            toast("خواندن فایل ممکن نشد.")
            return
        }
        val parsed = try {
            Backup.parse(text)
        } catch (e: IllegalArgumentException) {
            AlertDialog.Builder(this)
                .setTitle("فایل نامعتبر")
                .setMessage(e.message)
                .setPositiveButton("باشه", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("بازیابی اطلاعات")
            .setMessage(
                "همه اطلاعات فعلی (مشخصات، دانش‌آموزان و سوابق همه ماه‌ها) با محتوای فایل جایگزین می‌شود.\n\n" +
                    "محتوای فایل: " + Fa.n(parsed.students.size) + " دانش‌آموز و " +
                    Fa.n(parsed.records.size) + " ثبت حضور و غیاب.\n\nادامه می‌دهید؟"
            )
            .setPositiveButton("بازیابی") { _, _ ->
                try {
                    Backup.restore(db, parsed)
                    render()
                    toast("اطلاعات بازیابی شد.")
                } catch (e: Exception) {
                    toast("بازیابی ناموفق بود؛ اطلاعات قبلی دست‌نخورده ماند.")
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}
