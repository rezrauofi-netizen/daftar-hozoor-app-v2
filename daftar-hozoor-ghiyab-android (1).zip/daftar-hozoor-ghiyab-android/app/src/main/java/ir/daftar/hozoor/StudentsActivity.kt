package ir.daftar.hozoor

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged

class StudentsActivity : AppCompatActivity() {

    private lateinit var db: Db
    private lateinit var listBox: LinearLayout
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)

        val root = vbox()
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(10), dp(10), dp(10), dp(10))
        root.addView(tv("دانش‌آموزان", 22f, C.NAVY, true))

        val search = EditText(this)
        search.hint = "جست‌وجوی دانش‌آموز"
        search.setSingleLine()
        search.textDirection = View.TEXT_DIRECTION_RTL
        search.background = shape(Color.WHITE, C.LINE, dpf(12), dp(1))
        search.setPadding(dp(12), dp(10), dp(12), dp(10))
        search.doAfterTextChanged {
            query = it?.toString() ?: ""
            render()
        }
        root.addView(search, lp(MATCH, WRAP, 0f, 6))

        val scroll = ScrollView(this)
        listBox = vbox()
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val add = button("افزودن دانش‌آموز")
        add.setOnClickListener { addDialog() }
        root.addView(add, lp(MATCH, WRAP, 0f, 4))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        listBox.removeAllViews()
        val list = db.students(query)
        if (list.isEmpty()) {
            listBox.addView(tv("دانش‌آموزی یافت نشد.", 15f, C.NAVY).also { it.setPadding(0, dp(30), 0, 0) })
            return
        }
        list.forEachIndexed { i, s ->
            val t = tv(Fa.n(i + 1) + ".  " + s.name, 16f)
            t.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            t.background = shape(Color.WHITE, C.LINE, dpf(10), dp(1))
            t.setPadding(dp(14), dp(14), dp(14), dp(14))
            t.setOnClickListener { actions(s) }
            listBox.addView(t, lp(MATCH, WRAP, 0f, 3))
        }
    }

    private fun actions(s: Student) {
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setItems(arrayOf("ویرایش نام", "حذف دانش‌آموز")) { _, which ->
                if (which == 0) renameDialog(s) else deleteDialog(s)
            }
            .show()
    }

    private fun addDialog() {
        val et = EditText(this)
        et.hint = "هر نام در یک خط"
        et.minLines = 3
        et.textDirection = View.TEXT_DIRECTION_RTL
        AlertDialog.Builder(this)
            .setTitle("افزودن دانش‌آموز")
            .setView(et)
            .setPositiveButton("افزودن") { _, _ ->
                val names = et.text.toString().split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                for (n in names) db.addStudent(n)
                if (names.isNotEmpty()) Toast.makeText(this, Fa.n(names.size) + " نام اضافه شد.", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun renameDialog(s: Student) {
        val et = EditText(this)
        et.setText(s.name)
        et.setSingleLine()
        et.textDirection = View.TEXT_DIRECTION_RTL
        AlertDialog.Builder(this)
            .setTitle("ویرایش نام")
            .setView(et)
            .setPositiveButton("ذخیره") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) db.renameStudent(s.id, n)
                render()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun deleteDialog(s: Student) {
        AlertDialog.Builder(this)
            .setTitle("حذف دانش‌آموز")
            .setMessage("با حذف «" + s.name + "»، تمام سوابق حضور و غیاب او در همه ماه‌ها نیز پاک می‌شود و قابل بازگشت نیست. مطمئن هستید؟")
            .setPositiveButton("حذف") { _, _ ->
                db.deleteStudent(s.id)
                render()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}
