package ir.daftar.hozoor

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object C {
    val BG = Color.parseColor("#EAF5FD")
    val BLUE = Color.parseColor("#2E75B6")
    val NAVY = Color.parseColor("#1F4E79")
    val LINE = Color.parseColor("#9CC3E6")
    val TEXT = Color.parseColor("#222222")
    val HEAD_BG = Color.parseColor("#CDE8FB")
    val PINK = Color.parseColor("#FDE0EA")
    val PINK_D = Color.parseColor("#F08CB0")
    val GREEN = Color.parseColor("#E3F2CF")
    val GREEN_D = Color.parseColor("#8CC152")
    val YELLOW = Color.parseColor("#FFF6C4")
    val YELLOW_D = Color.parseColor("#F2D04D")
    val SKY = Color.parseColor("#D9EEFB")
    val PRES_BG = Color.parseColor("#C8F0C8")
    val PRES_T = Color.parseColor("#1B7F2A")
    val ABS_BG = Color.parseColor("#FFC9C9")
    val ABS_T = Color.parseColor("#C62828")
    val LATE_BG = Color.parseColor("#FFE0A3")
    val LATE_T = Color.parseColor("#9A5B00")
}

object Fa {
    val months = listOf("مهر", "آبان", "آذر", "دی", "بهمن", "اسفند", "فروردین", "اردیبهشت", "خرداد")
    val daysIn = intArrayOf(30, 30, 30, 30, 30, 29, 31, 31, 31)

    fun digits(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in '0'..'9') sb.append('۰' + (c - '0')) else sb.append(c)
        }
        return sb.toString()
    }

    fun n(i: Int): String = digits(i.toString())
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Int): Float = v * resources.displayMetrics.density

fun shape(fill: Int, stroke: Int, radius: Float, strokePx: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = radius
    g.setStroke(strokePx, stroke)
    return g
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.layoutDirection = View.LAYOUT_DIRECTION_RTL
    return l
}

fun Context.vbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.layoutDirection = View.LAYOUT_DIRECTION_RTL
    return l
}

fun Context.lp(w: Int, h: Int, weight: Float = 0f, m: Int = 3): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(m), dp(m), dp(m), dp(m))
    return p
}

fun Context.tv(text: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    t.gravity = Gravity.CENTER
    t.textDirection = View.TEXT_DIRECTION_RTL
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.cell(text: String, w: Int, h: Int, fill: Int, color: Int = C.TEXT, size: Float = 13f, bold: Boolean = false): TextView {
    val t = tv(text, size, color, bold)
    t.layoutParams = LinearLayout.LayoutParams(w, h)
    t.background = shape(fill, C.LINE, 0f, dp(1))
    t.setPadding(dp(3), 0, dp(3), 0)
    t.maxLines = 2
    t.ellipsize = TextUtils.TruncateAt.END
    return t
}

fun Context.button(text: String, fill: Int = C.BLUE, color: Int = Color.WHITE): TextView {
    val t = tv(text, 13f, color, true)
    t.background = shape(fill, fill, dpf(12), dp(1))
    t.setPadding(dp(4), dp(12), dp(4), dp(12))
    return t
}
