package ir.daftar.hozoor

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ReportActivity : AppCompatActivity() {

    private lateinit var db: Db
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)

        val root = vbox()
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(10), dp(10), dp(10), dp(10))
        root.addView(tv("گزارش کلی کلاس", 22f, C.NAVY, true))

        val sp = Spinner(this)
        sp.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val items = listOf("کل سال تحصیلی") + Fa.months.map { "ماه $it" }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                render(position - 1)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(sp, lp(MATCH, WRAP, 0f, 6))

        val scroll = ScrollView(this)
        listBox = vbox()
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(tv("برای دیدن سوابق ماه‌به‌ماه، روی نام دانش‌آموز بزنید.", 12f, C.NAVY))
        setContentView(root)
    }

    private fun row(name: String, a: String, b: String, c: String, fill: Int, bold: Boolean): LinearLayout {
        val h = dp(42)
        val w = dp(54)
        val r = hbox()
        val n = cell(name, 0, h, fill, C.NAVY, 14f, bold)
        n.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        r.addView(n, LinearLayout.LayoutParams(0, h, 1f))
        r.addView(cell(a, w, h, C.YELLOW, C.NAVY, 14f, bold))
        r.addView(cell(b, w, h, C.PINK, C.NAVY, 14f, bold))
        r.addView(cell(c, w, h, C.LATE_BG, C.NAVY, 14f, bold))
        return r
    }

    /** period: -1 = کل سال، ۰..۸ = ماه */
    private fun render(period: Int) {
        listBox.removeAllViews()
        val students = db.students("")
        val counts = db.counts()
        listBox.addView(row("نام", "حضور", "غیبت", "تأخیر", C.HEAD_BG, true))
        val sum = IntArray(3)
        for (s in students) {
            val t = IntArray(3)
            val arr = counts[s.id]
            if (arr != null) {
                for (m in 0..8) {
                    if (period == -1 || period == m) {
                        for (k in 0..2) t[k] += arr[m][k]
                    }
                }
            }
            for (k in 0..2) sum[k] += t[k]
            val r = row(s.name, Fa.n(t[0]), Fa.n(t[1]), Fa.n(t[2]), Color.WHITE, false)
            r.setOnClickListener { showBreakdown(s, arr) }
            listBox.addView(r)
        }
        listBox.addView(row("جمع کلاس", Fa.n(sum[0]), Fa.n(sum[1]), Fa.n(sum[2]), C.HEAD_BG, true))
    }

    private fun showBreakdown(s: Student, arr: Array<IntArray>?) {
        val sb = StringBuilder()
        if (arr != null) {
            for (m in 0..8) {
                val a = arr[m]
                if (a[0] + a[1] + a[2] > 0) {
                    sb.append(Fa.months[m]).append(": حضور ").append(Fa.n(a[0]))
                        .append(" | غیبت ").append(Fa.n(a[1]))
                        .append(" | تأخیر ").append(Fa.n(a[2])).append("\n")
                }
            }
        }
        if (sb.isEmpty()) sb.append("هنوز سابقه‌ای ثبت نشده است.")
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setMessage(sb.toString())
            .setPositiveButton("باشه", null)
            .show()
    }
}
